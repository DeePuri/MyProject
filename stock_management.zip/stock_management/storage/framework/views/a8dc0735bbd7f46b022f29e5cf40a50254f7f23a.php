<div id="footer" class="cf">

    <div class="column three">
        <strong>Mobile</strong>
        (02) 82653222
    </div> <!-- column -->

    <div class="column three">
        <strong>Location</strong>
        160 Sussex St, Sydney NSW 2000, Australia

        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3312.772817666068!2d151.20180291521027!3d-33.86974528065601!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6b12ae38d6975ca7%3A0xa1ded915f22b37f4!2s160%20Sussex%20St%2C%20Sydney%20NSW%202000%2C%20Australia!5e0!3m2!1sen!2sin!4v1580481524901!5m2!1sen!2sin"
                width="200" height="auto" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
    </div> <!-- column -->

    <div class="column three last">
        <strong>Hours</strong>
        <em>Everyday</em><br>
        6 :30 AM - 12:00 PM<br><br>
    </div> <!-- column -->

</div> <!-- footer -->
<small>&copy:<?php echo date('Y'); ?> <?php echo e(config('app.name', 'Urban Zest café')); ?></small>