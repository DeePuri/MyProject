<?php $__env->startSection('page-title', 'Home'); ?>



<?php $__env->startSection('content'); ?>
    <div id="team-members" class="cf">

        <h1>Our Team at Urban Zest Cafe</h1>
        <p>Our Mission & Vision :Our cafe started back in 2012 with the concept of fresh coffe for coffee lovers in
            Sydey. We collaborate with suppliers who produce extremely fresh coffee beans which suits the Australian
            Coffee Culture. As a team of young enterpreneurs, we aim to be one of the best coffee brewing coffee in
            Sydney </p>

        <hr>

        <?php $__currentLoopData = $teamMembers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="member">
                <img src="<?php echo e(asset('image/'.$member["img"].'.png')); ?>" alt="<?php echo e($member["name"]); ?>">
                <h2><?php echo e($member["name"]); ?></h2>
                <p><?php echo e($member["bio"]); ?></p>
            </div><!-- member -->
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div><!-- team-members -->

    <hr>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>