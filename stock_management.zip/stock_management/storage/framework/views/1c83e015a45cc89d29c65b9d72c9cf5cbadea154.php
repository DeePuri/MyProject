<?php $__env->startSection('content'); ?>
    <h1 class="mt-4">Sales Report</h1>
    <div class="">
        <div class="card">
            <div class="card-header">Yearly Product Sales</div>
            <div class="card-body">
                <div class='tableauPlaceholder' id='viz1580967449297' style='position: relative'>
                    <noscript><a href='#'><img alt=' '
                                               src='https:&#47;&#47;public.tableau.com&#47;static&#47;images&#47;Ur&#47;UrbanZestCafe&#47;Sheet3&#47;1_rss.png'
                                               style='border: none'/></a></noscript>
                    <object class='tableauViz' style='display:none;'>
                        <param name='host_url' value='https%3A%2F%2Fpublic.tableau.com%2F'/>
                        <param name='embed_code_version' value='3'/>
                        <param name='site_root' value=''/>
                        <param name='name' value='UrbanZestCafe&#47;Sheet3'/>
                        <param name='tabs' value='no'/>
                        <param name='toolbar' value='yes'/>
                        <param name='static_image'
                               value='https:&#47;&#47;public.tableau.com&#47;static&#47;images&#47;Ur&#47;UrbanZestCafe&#47;Sheet3&#47;1.png'/>
                        <param name='animate_transition' value='yes'/>
                        <param name='display_static_image' value='yes'/>
                        <param name='display_spinner' value='yes'/>
                        <param name='display_overlay' value='yes'/>
                        <param name='display_count' value='yes'/>
                        <param name='filter' value='publish=yes'/>
                    </object>
                </div>
                <script type='text/javascript'>                    var divElement = document.getElementById('viz1580967449297');
                    var vizElement = divElement.getElementsByTagName('object')[0];
                    vizElement.style.width = '100%';
                    // vizElement.style.height = (divElement.offsetWidth * 0.75) + 'px';
                    vizElement.style.height = '350px';
                    var scriptElement = document.createElement('script');
                    scriptElement.src = 'https://public.tableau.com/javascripts/api/viz_v1.js';
                    vizElement.parentNode.insertBefore(scriptElement, vizElement);                </script>
            </div>
        </div>
    </div>

    <div class="my-4">
        <div class="row">
            <div class="col-lg-6">
                <div class="card">
                    <div class="card-header">Sales for Customer Segment</div>
                    <div class="card-body">
                        <div class='tableauPlaceholder' id='viz1580967601065' style='position: relative'>
                            <noscript><a href='#'><img alt=' '
                                                       src='https:&#47;&#47;public.tableau.com&#47;static&#47;images&#47;Ur&#47;UrbanZestCafeSegment&#47;Sheet4&#47;1_rss.png'
                                                       style='border: none'/></a></noscript>
                            <object class='tableauViz' style='display:none;'>
                                <param name='host_url' value='https%3A%2F%2Fpublic.tableau.com%2F'/>
                                <param name='embed_code_version' value='3'/>
                                <param name='site_root' value=''/>
                                <param name='name' value='UrbanZestCafeSegment&#47;Sheet4'/>
                                <param name='tabs' value='no'/>
                                <param name='toolbar' value='yes'/>
                                <param name='static_image'
                                       value='https:&#47;&#47;public.tableau.com&#47;static&#47;images&#47;Ur&#47;UrbanZestCafeSegment&#47;Sheet4&#47;1.png'/>
                                <param name='animate_transition' value='yes'/>
                                <param name='display_static_image' value='yes'/>
                                <param name='display_spinner' value='yes'/>
                                <param name='display_overlay' value='yes'/>
                                <param name='display_count' value='yes'/>
                                <param name='filter' value='publish=yes'/>
                            </object>
                        </div>
                        <script type='text/javascript'>                    var divElement = document.getElementById('viz1580967601065');
                            var vizElement = divElement.getElementsByTagName('object')[0];
                            vizElement.style.width = '100%';
                            // vizElement.style.height = (divElement.offsetWidth * 0.75) + 'px';
                            vizElement.style.height = '300px';
                            var scriptElement = document.createElement('script');
                            scriptElement.src = 'https://public.tableau.com/javascripts/api/viz_v1.js';
                            vizElement.parentNode.insertBefore(scriptElement, vizElement);                </script>
                    </div>
                </div>
            </div>

            <div class="col-lg-6">
                <div class="card">
                    <div class="card-header">Sales by Region</div>
                    <div class="card-body">
                        <div class='tableauPlaceholder' id='viz1580967815754' style='position: relative; height: 300px'>
                            <noscript><a href='#'><img alt=' '
                                                       src='https:&#47;&#47;public.tableau.com&#47;static&#47;images&#47;Ur&#47;UrbanZestCafeRegion&#47;Sheet4&#47;1_rss.png'
                                                       style='border: none'/></a></noscript>
                            <object class='tableauViz' style='display:none;'>
                                <param name='host_url' value='https%3A%2F%2Fpublic.tableau.com%2F'/>
                                <param name='embed_code_version' value='3'/>
                                <param name='site_root' value=''/>
                                <param name='name' value='UrbanZestCafeRegion&#47;Sheet4'/>
                                <param name='tabs' value='no'/>
                                <param name='toolbar' value='yes'/>
                                <param name='static_image'
                                       value='https:&#47;&#47;public.tableau.com&#47;static&#47;images&#47;Ur&#47;UrbanZestCafeRegion&#47;Sheet4&#47;1.png'/>
                                <param name='animate_transition' value='yes'/>
                                <param name='display_static_image' value='yes'/>
                                <param name='display_spinner' value='yes'/>
                                <param name='display_overlay' value='yes'/>
                                <param name='display_count' value='yes'/>
                                <param name='filter' value='publish=yes'/>
                            </object>
                        </div>
                        <script type='text/javascript'>                    var divElement = document.getElementById('viz1580967815754');
                            var vizElement = divElement.getElementsByTagName('object')[0];
                            vizElement.style.width = '100%';
                            // vizElement.style.height = (divElement.offsetWidth * 0.75) + 'px';
                            vizElement.style.height = '300px';
                            var scriptElement = document.createElement('script');
                            scriptElement.src = 'https://public.tableau.com/javascripts/api/viz_v1.js';
                            vizElement.parentNode.insertBefore(scriptElement, vizElement);                </script>
                    </div>
                </div>
            </div>
        </div>
      
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>