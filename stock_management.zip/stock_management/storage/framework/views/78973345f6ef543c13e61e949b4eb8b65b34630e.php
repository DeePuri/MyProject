<?php $__env->startSection('page-title', 'Contact'); ?>



<?php $__env->startSection('content'); ?>
    <div id="contact">
        <hr>

        <?php if($submitted == 'submitted'): ?>

            <h5>Thanks for contacting Franklin's!</h5>
            <p>Please allow 24 hours for a response.</p>
            <p><a href="/" class="button block">&laquo; Go to Home Page</a></p>


        <?php else: ?>
            <h1>Get in touch with us!</h1>

            <?php if($errors->any()): ?>
                <?php
                print_r($errors->all());
                ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form method="post" action="/contact" id="contact-form">

            <?php echo e(csrf_field()); ?> <!-- Cross Site Forgery Prevention -->
                <label for="name">Your name</label>
                <input type="text" id="name" name="name">

                <label for="email">Your email</label>
                <input type="email" id="email" name="email">

                <label for="message">and your message</label>
                <textarea id="message" name="message"></textarea>

                <input type="checkbox" id="subscribe" value="Subscribe" name="subscribe"> <label for="subscribe">Subscribe
                    to newsletter</label>

                <input type="submit" class="button next" name="contact_submit" value="Send Message">
            </form>
        <?php endif; ?>
        <hr>

    </div> <!--Contact-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>