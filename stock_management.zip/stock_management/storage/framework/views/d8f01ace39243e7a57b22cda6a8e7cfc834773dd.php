<?php $__env->startSection('content'); ?>
    <h1 class="mt-4">Messages</h1>
    <div class="">
        <table class="table table-bordered table-hover">
            <tbody>
            <tr>
                <th width="5%">#</th>
                <th width="25%">Name</th>
                <th width="30%">Email</th>
                <th>Message</th>
            </tr>
            <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($index + 1); ?></td>
                    <td><?php echo e($message->name); ?></td>
                    <td><?php echo e($message->email); ?></td>
                    <td><?php echo e($message->message); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if($messages->isEmpty()): ?>
                <tr>
                    <td align="center" colspan="5">No result found.</td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
        <?php echo e($messages->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>