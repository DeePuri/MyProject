<?php $__env->startSection('content'); ?>
    <h1 class="mt-4">Manage Menu Item</h1>
    <div class="p-0 col-lg-6">
        <div class="card">
            <div class="card-header">Manage Ingredients</div>
            <div class="card-body">
                <?php echo $__env->make('layouts.partials._status', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <h3 class="mb-3"><?php echo e($menu->product_name); ?></h3>

                <?php if(!$ingredients->isEmpty()): ?>
                    <strong>Used Ingredients</strong>

                    <table class="table table-bordered">
                        <thead>
                        <tr>
                            <td>Material</td>
                            <td>Quantity</td>
                            <td></td>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $ingredients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php echo e($item->raw_material->material); ?>

                                </td>
                                <td>
                                    <?php echo e($item->quantity); ?>

                                </td>
                                <td>
                                    <a href="<?php echo e(route('ingredients.delete', $item->id)); ?>"
                                       class="btn btn-sm btn-danger">Delete</a>
                                </td>
                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php endif; ?>


                <h3 class="mt-4">Add Ingredient</h3>
                <?php echo Form::model($ingredients, ['route' => ['ingredients.save', $menu_id], 'method' => 'post']); ?>

                <?php $__empty_1 = true; $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="form-group">
                        <hr/>
                        <div class="row d-flex">
                            <div class="col-3"><?php echo e(Form::label($item->material, null, ['class' => 'control-label'])); ?></div>
                            <div class="col-5"><?php echo e(Form::number('quantity['.$item->id.']', null, array_merge(['class' => 'form-control','placeholder'=>'Quantity']))); ?></div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p>No Ingredient found</p>
                <?php endif; ?>

                <div class="form-group">
                    <div class="row d-flex">
                        <div class="col-3">
                        </div>
                        <div class="col-5">
                            <?php echo e(Form::submit('Save', ['class' => 'btn btn-primary'])); ?>

                        </div>
                    </div>

                </div>

                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>