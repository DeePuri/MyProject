<?php $__env->startSection('content'); ?>
    <h1 class="mt-4">Manage Users</h1>
    <div class="p-0 col-lg-6">
        <div class="card">
            <div class="card-header"><?php echo e(($id > 0)?'Edit':'Add'); ?> User</div>
            <div class="card-body">
                <?php echo $__env->make('layouts.partials._status', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <?php echo Form::model($user, ['route' => ['user.store', $id], 'method' => 'post']); ?>


                <div class="form-group">
                    <?php echo e(Form::label('Staff Name', null, ['class' => 'control-label'])); ?>

                    <?php echo e(Form::text('name', null, array_merge(['class' => 'form-control', 'required']))); ?>

                </div>

                <div class="form-group">
                    <?php echo e(Form::label('Email', null, ['class' => 'control-label'])); ?>

                    <?php echo e(Form::email('email', null, array_merge(['class' => 'form-control', 'required']))); ?>

                </div>

                <div class="form-group">
                    <?php echo e(Form::label('Password', null, ['class' => 'control-label'])); ?>

                    <?php echo e(Form::password('password', array_merge(['class' => 'form-control']))); ?>

                </div>

                <div class="form-group">
                    <?php echo e(Form::label('Confirm Password', null, ['class' => 'control-label'])); ?>

                    <?php echo e(Form::password('password_confirmation', array_merge(['class' => 'form-control']))); ?>

                </div>

                <div class="form-group">
                    <?php echo e(Form::submit('Submit', ['class' => 'btn btn-primary'])); ?>

                </div>

                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>