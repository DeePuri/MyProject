<?php $__env->startSection('page-title', 'Menu'); ?>



<?php $__env->startSection('content'); ?>

    <div id="menu-items">

        <?php echo $__env->make('layouts.partials._status', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <h1>Our Delicious Menu</h1>
        <p>Like our team, our menu is very small &mdash; but dang, does it ever pack a punch!</p>
        <p><em>Click any menu item to learn more about it.</em></p>

        <hr>

        <ul>
            <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="/dish/<?php echo e($menus->slug); ?>"><?php echo e($menus->product_name); ?></a>
                    <sup>$</sup><?php echo e($menus->price); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>

    </div><!-- team-members -->

    <hr>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>