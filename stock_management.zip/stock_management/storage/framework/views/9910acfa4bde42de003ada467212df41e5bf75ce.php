<div class="mt-4">
    <div class="card">
        <div class="card-header">
            Low Stock Materials
        </div>
        <div class="card-body p-0">
            <table class="table table-bordered table-hover">
                <tbody>
                <tr>
                    <th width="5%">#</th>
                    <th width="">Name</th>
                    <th width="">Stock Quantity</th>
                    <th></th>
                </tr>
                <?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($index + 1); ?></td>
                        <td><?php echo e($item->material); ?></td>
                        <td><?php echo e($item->quantity); ?></td>
                        <td  width="15%" align="center">
                            <a href="<?php echo e(route('materials.edit', $item->id)); ?>" class="btn btn-sm btn-info">Edit</a>
                            <a href="<?php echo e(route('materials.delete', $item->id)); ?>" class="btn btn-sm btn-danger">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if($stocks->isEmpty()): ?>
                    <tr>
                        <td align="center" colspan="5">No result found.</td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>