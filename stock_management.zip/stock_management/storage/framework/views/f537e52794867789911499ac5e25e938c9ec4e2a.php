<?php $__env->startSection('content'); ?>
    <h1 class="mt-4">Menus</h1>
    <div class="">
        <table class="table table-bordered table-hover">
            <tbody>
            <tr>
                <th width="5%">#</th>
                <th width="">Name</th>
                <th width="">Price</th>
                <th></th>
                <th></th>
            </tr>
            <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($index + 1); ?></td>
                    <td><?php echo e($menu->product_name); ?></td>
                    <td><?php echo e($menu->price); ?></td>
                    <td width="10%">
                        <a href="<?php echo e(route('ingredients.add', $menu->id)); ?>" class="btn btn-sm btn-secondary">Add Ingredients</a>
                    </td>
                    <td  width="15%" align="center">
                        <a href="<?php echo e(route('menus.edit', $menu->id)); ?>" class="btn btn-sm btn-info">Edit</a>
                        <a href="<?php echo e(route('menus.delete', $menu->id)); ?>" class="btn btn-sm btn-danger">Delete</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if($menus->isEmpty()): ?>
                <tr>
                    <td align="center" colspan="5">No result found.</td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
        <?php echo e($menus->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>