<?php $__env->startSection('page-title', 'Menu'); ?>



<?php $__env->startSection('content'); ?>
    <hr>

    <div id="dish">

        <?php echo $__env->make('layouts.partials._status', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <h1><?php echo e($dish->product_name); ?></h1>
        <strong style="font-size: 18px">Price: <sup>$</sup><?php echo e($dish->price); ?></strong>
        <br>
        <p><em>Suggested tip: <sup>$</sup><?php echo e($tip); ?></em></p>

        <strong>Ingredients:</strong>

        <?php $__currentLoopData = $dish->ingredient; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingredient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p style="margin-bottom: 5px">
                ~ <?php echo e($ingredient->raw_material->material); ?>

            </p>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if($dish->checkStock()): ?>

            <?php if(auth()->check()): ?>
                <?php echo Form::model([], ['route' => ['place-order', $dish->id], 'method' => 'post']); ?>

                <input type="submit" class="button next" value="Place Order" style="width: 200px;"/>
                <?php echo Form::close(); ?>

            <?php else: ?>
                <?php echo Form::model([], ['route' => ['payment', $dish->id], 'method' => 'post']); ?>

                <input type="submit" class="button next" value="Place Order" style="width: 200px;"/>
                <?php echo Form::close(); ?>

            <?php endif; ?>
        <?php else: ?>
            <p class="text-error">
                Sorry this item is out of stock.
            </p>
        <?php endif; ?>
    </div><!-- dish -->

    <hr>

    <a href="/menu" class="button previous">&laquo; Back to Menu</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>