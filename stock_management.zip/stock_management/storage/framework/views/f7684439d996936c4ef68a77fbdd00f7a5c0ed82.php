<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('page-title'); ?> | Urban Zest Café</title>

    <!-- Styles -->
    <link href="<?php echo e(asset('css/frontend.css')); ?>" rel="stylesheet">
</head>
<body id="final-example">

    <div class="wrapper">
        <div id="banner">
            <a href="/" title="Return to Home">
                <img src="<?php echo e(asset('image/banner.png')); ?>" alt="Banner">
            </a>
        </div>

        <div id="nav">
            <?php echo $__env->make('layouts.partials.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div class="content">
            <?php echo $__env->yieldContent('content'); ?>

            <?php echo $__env->make('layouts.partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>

    </div>
</body>
</html>
