<?php $__env->startSection('content'); ?>
    <h1 class="mt-4">Manage Menus</h1>
    <div class="p-0 col-lg-6">
        <div class="card">
            <div class="card-header"><?php echo e(($id > 0)?'Edit':'Add'); ?> Menu Item</div>
            <div class="card-body">
                <?php echo $__env->make('layouts.partials._status', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <?php echo Form::model($menu, ['route' => ['menus.store', $id], 'method' => 'post']); ?>


                <div class="form-group">
                    <?php echo e(Form::label('Menu Label', null, ['class' => 'control-label'])); ?>

                    <?php echo e(Form::text('product_name', null, array_merge(['class' => 'form-control', 'required']))); ?>

                </div>

                <div class="form-group">
                    <?php echo e(Form::label('Price', null, ['class' => 'control-label'])); ?>

                    <?php echo e(Form::text('price', null, array_merge(['class' => 'form-control', 'required']))); ?>

                </div>

                <div class="form-group">
                    <?php echo e(Form::submit('Submit', ['class' => 'btn btn-primary'])); ?>

                </div>

                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>