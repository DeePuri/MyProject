<?php $__env->startSection('content'); ?>
    <h1 class="mt-4">Raw Materials</h1>
    <div class="">
        <table class="table table-bordered table-hover">
            <tbody>
            <tr>
                <th width="5%">#</th>
                <th width="">Name</th>
                <th width="">Stock Quantity</th>
                <th></th>
            </tr>
            <?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($index + 1); ?></td>
                    <td><?php echo e($item->material); ?></td>
                    <td><?php echo e($item->quantity); ?></td>
                    <td  width="15%" align="center">
                        <a href="<?php echo e(route('materials.edit', $item->id)); ?>" class="btn btn-sm btn-info">Edit</a>
                        <a href="<?php echo e(route('materials.delete', $item->id)); ?>" class="btn btn-sm btn-danger">Delete</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if($materials->isEmpty()): ?>
                <tr>
                    <td align="center" colspan="5">No result found.</td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
        <?php echo e($materials->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>