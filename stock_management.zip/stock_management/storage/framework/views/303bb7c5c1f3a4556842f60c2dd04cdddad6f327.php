<?php $__env->startSection('content'); ?>
    <h1 class="mt-4">Manage Raw Material</h1>
    <div class="p-0 col-lg-6">
        <div class="card">
            <div class="card-header"><?php echo e(($id > 0)?'Edit':'Add'); ?> Raw Material</div>
            <div class="card-body">
                <?php echo $__env->make('layouts.partials._status', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <?php echo Form::model($material, ['route' => ['materials.store', $id], 'method' => 'post']); ?>


                <div class="form-group">
                    <?php echo e(Form::label('Material Name', null, ['class' => 'control-label'])); ?>

                    <?php echo e(Form::text('material', null, array_merge(['class' => 'form-control', 'required']))); ?>

                </div>

                <div class="form-group">
                    <?php echo e(Form::label('Stock Quantity', null, ['class' => 'control-label'])); ?>

                    <?php echo e(Form::number('quantity', null, array_merge(['class' => 'form-control', 'required']))); ?>

                </div>

                <div class="form-group">
                    <?php echo e(Form::submit('Submit', ['class' => 'btn btn-primary'])); ?>

                </div>

                <?php echo Form::close(); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>