<?php $__env->startSection('content'); ?>
    <h1 class="mt-4">Orders</h1>
    <div class="">
        <table class="table table-bordered table-hover">
            <tbody>
            <tr>
                <th width="5%">#</th>
                <th width="">Name</th>
                <th width="">Price</th>
                <th width="">Quantity</th>
                <th width="">Date</th>
            </tr>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($index + 1); ?></td>
                    <td><?php echo e($order->product->product_name); ?></td>
                    <td><?php echo e($order->product->price); ?></td>
                    <td><?php echo e($order->quantity); ?></td>
                    <td><?php echo e($order->created_at); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if($orders->isEmpty()): ?>
                <tr>
                    <td align="center" colspan="5">No result found.</td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
        <?php echo e($orders->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>