<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/', 'FrontendController@index')->name('home');
Route::get('/team', 'FrontendController@team')->name('team');
Route::get('/menu', 'FrontendController@menu')->name('menu');
Route::get('/dish/{item?}', 'FrontendController@dish')->name('menu');
Route::get('/contact/{submitted?}', 'FrontendController@contact')->name('contact');
Route::post('/contact', 'FrontendController@contactUs')->name('contact-us');

Auth::routes(['register' => false]);

Route::post('/order/{id}', 'OrdersController@placeOrder')->name('place-order');

Route::post('payment/{id?}', 'PaymentController@payment')->name('payment');
Route::get('cancel', 'PaymentController@cancel')->name('payment.cancel');
Route::get('payment/success/{id?}', 'PaymentController@success')->name('payment.success');

//After login
Route::group(['middleware' => 'auth', 'prefix' => 'admin'], function () {
    Route::get('/', function () {
        return redirect('/dashboard');
    });

    Route::get('/dashboard', 'DashboardController@index')->name('dashboard');

    Route::get('/menus/list', 'MenusController@index')->name('menus.list');
    Route::get('/menus/create', 'MenusController@create')->name('menus.create');
    Route::post('/menus/store/{id?}', 'MenusController@store')->name('menus.store');
    Route::get('/menus/edit/{id?}', 'MenusController@edit')->name('menus.edit');
    Route::get('/menus/delete/{id?}', 'MenusController@destroy')->name('menus.delete');

    Route::get('/ingredients/add/{id?}', 'IngredientsController@add')->name('ingredients.add');
    Route::post('/ingredients/store/{id?}', 'IngredientsController@store')->name('ingredients.save');
    Route::get('/ingredients/delete/{id?}', 'IngredientsController@delete')->name('ingredients.delete');

    Route::get('/materials/list', 'MaterialsController@index')->name('materials.list');
    Route::get('/materials/create', 'MaterialsController@create')->name('materials.create');
    Route::post('/materials/store/{id?}', 'MaterialsController@store')->name('materials.store');
    Route::get('/materials/edit/{id?}', 'MaterialsController@edit')->name('materials.edit');
    Route::get('/materials/delete/{id?}', 'MaterialsController@destroy')->name('materials.delete');

    Route::get('/user/list', 'UserController@index')->name('user.list');
    Route::get('/user/create', 'UserController@create')->name('user.create');
    Route::post('/user/store/{id?}', 'UserController@store')->name('user.store');
    Route::get('/user/edit/{id?}', 'UserController@edit')->name('user.edit');
    Route::get('/user/delete/{id?}', 'UserController@destroy')->name('user.delete');

    Route::get('/sales/report', 'SalesReportController@report')->name('sales.report');

    Route::get('/orders/list', 'OrdersController@index')->name('orders.list');

    Route::get('/messages', 'ContactMessagesController@index')->name('messages');
});