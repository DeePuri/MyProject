<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $admin = new \App\User();
        $admin->name = "Admin";
        $admin->email = "admin@admin.com";
        $admin->password = bcrypt('admin@123');
        $admin->role = 'admin';
        $admin->save();


        $admin = new \App\User();
        $admin->name = "Staff";
        $admin->email = "staff@staff.com";
        $admin->password = bcrypt('staff@123');
        $admin->role = 'staff';
        $admin->save();
    }
}
