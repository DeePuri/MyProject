@section('page-title', 'Menu')

@extends('layouts.frontend')

@section('content')

    <div id="menu-items">

        @include('layouts.partials._status')

        <h1>Our Delicious Menu</h1>
        <p>Like our team, our menu is very small &mdash; but dang, does it ever pack a punch!</p>
        <p><em>Click any menu item to learn more about it.</em></p>

        <hr>

        <ul>
            @foreach($menus as $menus)
                <li><a href="/dish/{{ $menus->slug }}">{{ $menus->product_name}}</a>
                    <sup>$</sup>{{ $menus->price }}</li>
            @endforeach
        </ul>

    </div><!-- team-members -->

    <hr>
@endsection