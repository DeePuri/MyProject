@section('page-title', 'Reservation')

@extends('layouts.frontend')

@section('content')

@endsection