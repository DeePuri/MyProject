@section('page-title', 'Home')

@extends('layouts.frontend')

@section('content')
    <div id="team-members" class="cf">

        <h1>Our Team at Urban Zest Cafe</h1>
        <p>Our Mission & Vision :Our cafe started back in 2012 with the concept of fresh coffe for coffee lovers in
            Sydey. We collaborate with suppliers who produce extremely fresh coffee beans which suits the Australian
            Coffee Culture. As a team of young enterpreneurs, we aim to be one of the best coffee brewing coffee in
            Sydney </p>

        <hr>

        @foreach($teamMembers as $member)
            <div class="member">
                <img src="{{asset('image/'.$member["img"].'.png')}}" alt="{{ $member["name"] }}">
                <h2>{{ $member["name"]}}</h2>
                <p>{{ $member["bio"]}}</p>
            </div><!-- member -->
        @endforeach

    </div><!-- team-members -->

    <hr>
@endsection