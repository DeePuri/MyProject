@section('page-title', 'Menu')

@extends('layouts.frontend')

@section('content')
    <hr>

    <div id="dish">

        @include('layouts.partials._status')

        <h1>{{$dish->product_name}}</h1>
        <strong style="font-size: 18px">Price: <sup>$</sup>{{$dish->price}}</strong>
        <br>
        <p><em>Suggested tip: <sup>$</sup>{{$tip}}</em></p>

        <strong>Ingredients:</strong>

        @foreach($dish->ingredient as $ingredient)
            <p style="margin-bottom: 5px">
                ~ {{ $ingredient->raw_material->material }}
            </p>
        @endforeach

        @if($dish->checkStock())

            @if(auth()->check())
                {!! Form::model([], ['route' => ['place-order', $dish->id], 'method' => 'post']) !!}
                <input type="submit" class="button next" value="Place Order" style="width: 200px;"/>
                {!! Form::close() !!}
            @else
                {!! Form::model([], ['route' => ['payment', $dish->id], 'method' => 'post']) !!}
                <input type="submit" class="button next" value="Place Order" style="width: 200px;"/>
                {!! Form::close() !!}
            @endif
        @else
            <p class="text-error">
                Sorry this item is out of stock.
            </p>
        @endif
    </div><!-- dish -->

    <hr>

    <a href="/menu" class="button previous">&laquo; Back to Menu</a>
@endsection