@section('page-title', 'Home')

@extends('layouts.frontend')

@section('content')
    <div id="philosophy">
        <hr>

        <h1>Urban Zest Café</h1>
        <p>Welcome to Urban Zest Cafe</p>
        <p>"Where your morning starts with the refreshing sip of coffee and a delightful breakfast"</p>

        <hr>
    </div><!-- philosophy -->
@endsection