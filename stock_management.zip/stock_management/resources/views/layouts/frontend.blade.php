<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>@yield('page-title') | Urban Zest Café</title>

    <!-- Styles -->
    <link href="{{ asset('css/frontend.css') }}" rel="stylesheet">
</head>
<body id="final-example">

    <div class="wrapper">
        <div id="banner">
            <a href="/" title="Return to Home">
                <img src="{{ asset('image/banner.png') }}" alt="Banner">
            </a>
        </div>

        <div id="nav">
            @include('layouts.partials.navbar')
        </div>
        <div class="content">
            @yield('content')

            @include('layouts.partials.footer')
        </div>

    </div>
</body>
</html>
