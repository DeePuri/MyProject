@if ($errors->any())
    <div class="alert alert-danger ">
        <ul class="m-0">
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif
@if (\Session::has('success'))
    <div class="alert alert-success mb-0">
        <p class="m-0">{{ \Session::get('success') }}</p>
    </div><br />
@endif