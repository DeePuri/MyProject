<div id="layoutSidenav_nav">
    <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
        <div class="sb-sidenav-menu">
            <div class="nav">
                <a class="nav-link" href="{{ route('dashboard') }}">
                    <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                    Dashboard
                </a>
                <div class="sb-sidenav-menu-heading pt-2 pb-0">Items</div>
                <a class="nav-link collapsed pt-1" href="#" data-toggle="collapse" data-target="#addMenus"
                   aria-expanded="false" aria-controls="collapseLayouts">
                    <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                    Menu Items
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse" id="addMenus" aria-labelledby="headingOne" data-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav">
                        <a class="nav-link py-1" href="{{ route('menus.create') }}">Add Menus</a>
                        <a class="nav-link py-1" href="{{ route('menus.list') }}">Menus List</a>
                    </nav>
                </div>

                <a class="nav-link collapsed pt-2" href="#" data-toggle="collapse" data-target="#rawMaterials"
                   aria-expanded="false" aria-controls="rawMaterials">
                    <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                    Raw Materials
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse" id="rawMaterials" aria-labelledby="headingOne" data-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav">
                        <a class="nav-link py-1" href="{{ route('materials.create') }}">Add Materials</a>
                        <a class="nav-link py-1" href="{{ route('materials.list') }}">Materials List</a>
                    </nav>
                </div>

                <a class="nav-link collapsed pt-2" href="#" data-toggle="collapse" data-target="#users"
                   aria-expanded="false" aria-controls="users">
                    <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                    Users
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse" id="users" aria-labelledby="headingOne" data-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav">
                        <a class="nav-link py-1" href="{{ route('user.create') }}">Add User</a>
                        <a class="nav-link py-1" href="{{ route('user.list') }}">Users List</a>
                    </nav>
                </div>

                <a class="nav-link" href="{{ route('sales.report') }}">
                    <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                    Sales Report
                </a>

                <a class="nav-link" href="{{ route('orders.list') }}">
                    <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                    Orders
                </a>

                <a class="nav-link" href="{{ route('messages') }}">
                    <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                    Messages
                </a>
            </div>
        </div>

        <div class="sb-sidenav-footer">
            <div class="small">Logged in as:</div>
            {{ auth()->user()->name }}
        </div>
    </nav>
</div>