<?php

$navItems = array(

    array(
        "slug"  => "/",
        "title" => "Home"
    ),

    array(
        "slug"  => "/team",
        "title" => "Team"
    ),

    array(
        "slug"  => "/menu",
        "title" => "Menu"
    ),

    array(
        "slug"  => "/contact",
        "title" => "Contact"
    ),
    array(
        "slug"  => "/login",
        "title" => "Login"
    ),
);

?>
<ul>
    <?php
    foreach ($navItems as $item) {
    if($item['slug'] == '/login') {
    if(auth()->check()) { ?>
        <li>
            <a href="{{ route('logout') }}"
               onclick="event.preventDefault();  document.getElementById('logout-form').submit();">
                Logout
            </a>
            <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                {{ csrf_field() }}
            </form>
        </li>
    <?php }else {
        echo "<li><a href=\"$item[slug]\">$item[title]</a></li>";
    }

    } else {
        echo "<li><a href=\"$item[slug]\">$item[title]</a></li>";
    }

    }
    ?>
</ul>
