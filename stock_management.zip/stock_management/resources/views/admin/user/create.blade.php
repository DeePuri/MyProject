@extends('layouts.admin')

@section('content')
    <h1 class="mt-4">Manage Users</h1>
    <div class="p-0 col-lg-6">
        <div class="card">
            <div class="card-header">{{ ($id > 0)?'Edit':'Add' }} User</div>
            <div class="card-body">
                @include('layouts.partials._status')

                {!! Form::model($user, ['route' => ['user.store', $id], 'method' => 'post']) !!}

                <div class="form-group">
                    {{ Form::label('Staff Name', null, ['class' => 'control-label']) }}
                    {{ Form::text('name', null, array_merge(['class' => 'form-control', 'required'])) }}
                </div>

                <div class="form-group">
                    {{ Form::label('Email', null, ['class' => 'control-label']) }}
                    {{ Form::email('email', null, array_merge(['class' => 'form-control', 'required'])) }}
                </div>

                <div class="form-group">
                    {{ Form::label('Password', null, ['class' => 'control-label']) }}
                    {{ Form::password('password', array_merge(['class' => 'form-control'])) }}
                </div>

                <div class="form-group">
                    {{ Form::label('Confirm Password', null, ['class' => 'control-label']) }}
                    {{ Form::password('password_confirmation', array_merge(['class' => 'form-control'])) }}
                </div>

                <div class="form-group">
                    {{ Form::submit('Submit', ['class' => 'btn btn-primary']) }}
                </div>

                {!! Form::close() !!}
            </div>
        </div>
    </div>
@endsection
