@extends('layouts.admin')

@section('content')
    <h1 class="mt-4">Users</h1>
    <div class="">
        <table class="table table-bordered table-hover">
            <tbody>
            <tr>
                <th width="5%">#</th>
                <th width="">Name</th>
                <th width="">Email</th>
                <th>Created</th>
                <th></th>
            </tr>
            @foreach($users as $index=>$user)
                <tr>
                    <td>{{$index + 1}}</td>
                    <td>{{$user->name}}</td>
                    <td>{{$user->email}}</td>
                    <td>{{$user->created_at}}</td>
                    <td width="15%" align="center">
                        <a href="{{ route('user.edit', $user->id) }}" class="btn btn-sm btn-info">Edit</a>
                        <a href="{{ route('user.delete', $user->id) }}" class="btn btn-sm btn-danger">Delete</a>
                    </td>
                </tr>
            @endforeach

            @if($users->isEmpty())
                <tr>
                    <td align="center" colspan="5">No result found.</td>
                </tr>
            @endif

            </tbody>
        </table>
        {{ $users->links() }}
    </div>
@endsection
