<div class="mt-4">
    <div class="card">
        <div class="card-header">
            Low Stock Materials
        </div>
        <div class="card-body p-0">
            <table class="table table-bordered table-hover">
                <tbody>
                <tr>
                    <th width="5%">#</th>
                    <th width="">Name</th>
                    <th width="">Stock Quantity</th>
                    <th></th>
                </tr>
                @foreach($stocks as $index=>$item)
                    <tr>
                        <td>{{$index + 1}}</td>
                        <td>{{$item->material}}</td>
                        <td>{{$item->quantity}}</td>
                        <td  width="15%" align="center">
                            <a href="{{ route('materials.edit', $item->id) }}" class="btn btn-sm btn-info">Edit</a>
                            <a href="{{ route('materials.delete', $item->id) }}" class="btn btn-sm btn-danger">Delete</a>
                        </td>
                    </tr>
                @endforeach
                @if($stocks->isEmpty())
                    <tr>
                        <td align="center" colspan="5">No result found.</td>
                    </tr>
                @endif
                </tbody>
            </table>
        </div>
    </div>
</div>