<div class="card mt-4">
    <div class="card-header"><i class="fas fa-chart-bar mr-1"></i>Bar Chart Example</div>
    <div class="card-body">
        <div class="chart" style="width: 100%">
            <canvas id="myBarChart" height="100%" style="height: 100%;"></canvas>
        </div>
    </div>
</div>