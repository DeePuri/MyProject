@extends('layouts.admin')

@section('content')
    <h1 class="mt-4">Messages</h1>
    <div class="">
        <table class="table table-bordered table-hover">
            <tbody>
            <tr>
                <th width="5%">#</th>
                <th width="25%">Name</th>
                <th width="30%">Email</th>
                <th>Message</th>
            </tr>
            @foreach($messages as $index=>$message)
                <tr>
                    <td>{{$index + 1}}</td>
                    <td>{{$message->name}}</td>
                    <td>{{$message->email}}</td>
                    <td>{{$message->message}}</td>
                </tr>
            @endforeach
            @if($messages->isEmpty())
                <tr>
                    <td align="center" colspan="5">No result found.</td>
                </tr>
            @endif
            </tbody>
        </table>
        {{ $messages->links() }}
    </div>
@endsection
