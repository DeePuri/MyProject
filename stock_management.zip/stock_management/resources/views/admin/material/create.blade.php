@extends('layouts.admin')

@section('content')
    <h1 class="mt-4">Manage Raw Material</h1>
    <div class="p-0 col-lg-6">
        <div class="card">
            <div class="card-header">{{ ($id > 0)?'Edit':'Add' }} Raw Material</div>
            <div class="card-body">
                @include('layouts.partials._status')

                {!! Form::model($material, ['route' => ['materials.store', $id], 'method' => 'post']) !!}

                <div class="form-group">
                    {{ Form::label('Material Name', null, ['class' => 'control-label']) }}
                    {{ Form::text('material', null, array_merge(['class' => 'form-control', 'required'])) }}
                </div>

                <div class="form-group">
                    {{ Form::label('Stock Quantity', null, ['class' => 'control-label']) }}
                    {{ Form::number('quantity', null, array_merge(['class' => 'form-control', 'required'])) }}
                </div>

                <div class="form-group">
                    {{ Form::submit('Submit', ['class' => 'btn btn-primary']) }}
                </div>

                {!! Form::close() !!}
            </div>
        </div>
    </div>
@endsection
