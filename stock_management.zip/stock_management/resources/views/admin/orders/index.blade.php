@extends('layouts.admin')

@section('content')
    <h1 class="mt-4">Orders</h1>
    <div class="">
        <table class="table table-bordered table-hover">
            <tbody>
            <tr>
                <th width="5%">#</th>
                <th width="">Name</th>
                <th width="">Price</th>
                <th width="">Quantity</th>
                <th width="">Date</th>
            </tr>
            @foreach($orders as $index=>$order)
                <tr>
                    <td>{{$index + 1}}</td>
                    <td>{{$order->product->product_name}}</td>
                    <td>{{$order->product->price}}</td>
                    <td>{{$order->quantity}}</td>
                    <td>{{$order->created_at}}</td>
                </tr>
            @endforeach
            @if($orders->isEmpty())
                <tr>
                    <td align="center" colspan="5">No result found.</td>
                </tr>
            @endif
            </tbody>
        </table>
        {{ $orders->links() }}
    </div>
@endsection
