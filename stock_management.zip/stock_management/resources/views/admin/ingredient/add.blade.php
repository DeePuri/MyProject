@extends('layouts.admin')

@section('content')
    <h1 class="mt-4">Manage Menu Item</h1>
    <div class="p-0 col-lg-6">
        <div class="card">
            <div class="card-header">Manage Ingredients</div>
            <div class="card-body">
                @include('layouts.partials._status')

                <h3 class="mb-3">{{$menu->product_name}}</h3>

                @if(!$ingredients->isEmpty())
                    <strong>Used Ingredients</strong>

                    <table class="table table-bordered">
                        <thead>
                        <tr>
                            <td>Material</td>
                            <td>Quantity</td>
                            <td></td>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($ingredients as $item)
                            <tr>
                                <td>
                                    {{$item->raw_material->material}}
                                </td>
                                <td>
                                    {{$item->quantity}}
                                </td>
                                <td>
                                    <a href="{{ route('ingredients.delete', $item->id) }}"
                                       class="btn btn-sm btn-danger">Delete</a>
                                </td>
                            </tr>

                        @endforeach
                        </tbody>
                    </table>
                @endif


                <h3 class="mt-4">Add Ingredient</h3>
                {!! Form::model($ingredients, ['route' => ['ingredients.save', $menu_id], 'method' => 'post']) !!}
                @forelse($materials as $item)
                    <div class="form-group">
                        <hr/>
                        <div class="row d-flex">
                            <div class="col-3">{{ Form::label($item->material, null, ['class' => 'control-label']) }}</div>
                            <div class="col-5">{{ Form::number('quantity['.$item->id.']', null, array_merge(['class' => 'form-control','placeholder'=>'Quantity'])) }}</div>
                        </div>
                    </div>
                @empty
                    <p>No Ingredient found</p>
                @endforelse

                <div class="form-group">
                    <div class="row d-flex">
                        <div class="col-3">
                        </div>
                        <div class="col-5">
                            {{ Form::submit('Save', ['class' => 'btn btn-primary']) }}
                        </div>
                    </div>

                </div>

                {!! Form::close() !!}
            </div>
        </div>
    </div>
@endsection
