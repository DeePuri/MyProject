@extends('layouts.admin')

@section('content')
    <h1 class="mt-4">Menus</h1>
    <div class="">
        <table class="table table-bordered table-hover">
            <tbody>
            <tr>
                <th width="5%">#</th>
                <th width="">Name</th>
                <th width="">Price</th>
                <th></th>
                <th></th>
            </tr>
            @foreach($menus as $index=>$menu)
                <tr>
                    <td>{{$index + 1}}</td>
                    <td>{{$menu->product_name}}</td>
                    <td>{{$menu->price}}</td>
                    <td width="190px" align="center">
                        <a href="{{ route('ingredients.add', $menu->id) }}" class="btn btn-sm btn-secondary">Add Ingredients</a>
                    </td>
                    <td  width="15%" align="center">
                        <a href="{{ route('menus.edit', $menu->id) }}" class="btn btn-sm btn-info">Edit</a>
                        <a href="{{ route('menus.delete', $menu->id) }}" class="btn btn-sm btn-danger">Delete</a>
                    </td>
                </tr>
            @endforeach
            @if($menus->isEmpty())
                <tr>
                    <td align="center" colspan="5">No result found.</td>
                </tr>
            @endif
            </tbody>
        </table>
        {{ $menus->links() }}
    </div>
@endsection
