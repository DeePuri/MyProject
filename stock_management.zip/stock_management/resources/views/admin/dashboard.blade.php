@extends('layouts.admin')

@section('content')
    <h1 class="mt-4">Dashboard</h1>

    <div class="row">
        <div class="col-xl-3 col-md-6">
            <div class="card bg-info text-white mb-4">
                <div class="card-body h1">{{ $today }}</div>
                <div class="card-footer d-flex align-items-center justify-content-between">
                    <p class="small text-white stretched-link m-0">Today's Orders</p>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6">
            <div class="card bg-primary text-white mb-4">
                <div class="card-body h1">{{ $orders }}</div>
                <div class="card-footer d-flex align-items-center justify-content-between">
                    <p class="small text-white stretched-link m-0">Total Orders</p>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6">
            <div class="card bg-warning text-white mb-4">
                <div class="card-body h1">{{ $materials }}</div>
                <div class="card-footer d-flex align-items-center justify-content-between">
                    <p class="small text-white stretched-link m-0">Total Materials</p>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6">
            <div class="card bg-success text-white mb-4">
                <div class="card-body h1">{{ $menus }}</div>
                <div class="card-footer d-flex align-items-center justify-content-between">
                    <p class="small text-white stretched-link m-0">Total Menu Items</p>
                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript">
        var ordersData = {{ $chartData }};
        var ordersLabel = {!!  $chartLabel   !!};
    </script>
    @include('admin.dashboard.orders')

    @include('admin.dashboard.stock')

@endsection