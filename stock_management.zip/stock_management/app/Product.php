<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    protected $fillable = [
        'product_name', 'price', 'slug'
    ];

    public function ingredient()
    {
        return $this->hasMany(Ingredient::class);
    }

    public function checkStock()
    {
        $stock = true;

        foreach ($this->ingredient as $ingredient) {
            $quantity = $ingredient->raw_material->quantity;

            if ($quantity < 1) {
                $stock = false;
                break;
            }

        }

        return $stock;
    }
}
