<?php

namespace App\Http\Controllers;

use App\RawMaterial;
use Illuminate\Http\Request;

class MaterialsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $materials = RawMaterial::paginate(10);
        $data = [
            'materials' => $materials,
        ];

        return view('admin.material.index')->with($data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $data = [
            'material' => [],
            'id'       => 0
        ];

        return view('admin.material.create')->with($data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request, $id = 0)
    {
        $validatedData = $request->validate([
            'material' => 'required',
            'quantity' => 'required|numeric',
        ]);

        $data = $request->only(['material', 'quantity']);
        $data['slug'] = str_slug($request->RawMaterial_name);

        if ($id > 0) {
            RawMaterial::find($id)->update($data);
        } else {
            RawMaterial::create($data);
        }

        return back()->with('success', 'Material has been saved');
    }


    /**
     * Show the form for editing the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data = [
            'material' => RawMaterial::find($id),
            'id'       => $id
        ];

        return view('admin.material.create')->with($data);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        if ($id > 0) {
            RawMaterial::destroy([$id]);
            return back()->with('success', 'Item has been deleted successfully');
        } else {
            return back()->with('error', 'Item Not Found');
        }
    }
}
