<?php

namespace App\Http\Controllers;

use App\Ingredient;
use App\Order;
use App\Product;
use App\RawMaterial;
use Illuminate\Http\Request;
use Srmklive\PayPal\Services\ExpressCheckout;

class PaymentController extends Controller
{

    public function payment(Request $request, $id = 0)
    {
        if ($id < 1) {
            return back()->with('error', 'Item not found');
        }

        $data = $this->getOrderItem($id);

        $provider = new ExpressCheckout;

        $response = $provider->setExpressCheckout($data);

        return redirect($response['paypal_link']);
    }


    public function cancel($id = 0)
    {
        return redirect('/menu')->with('error', 'Something went wrong');
    }

    private function getOrderItem($id)
    {
        $menu = Product::find($id);

        $price = $menu->price;
        $data['items'] = [
            [
                'name'  => $menu->product_name,
                'price' => $price,
                'desc'  => "Online purchase: " . env('APP_NAME'),
                'qty'   => 1
            ]
        ];

        $data['invoice_id'] = uniqid();
        $data['invoice_description'] = "Order #{$data['invoice_id']} Invoice";
        $data['return_url'] = route('payment.success', $id);
        $data['cancel_url'] = route('payment.cancel', $id);
        $data['total'] = $price;


        return $data;
    }

    public function success(Request $request, $id = 0)
    {
        $provider = new ExpressCheckout;

        $token = $request->token;
        $response = $provider->getExpressCheckoutDetails($token);


        $PayerID = $request->PayerID;

        if (in_array(strtoupper($response['ACK']), ['SUCCESS', 'SUCCESSWITHWARNING'])) {

            $response = $provider->doExpressCheckoutPayment($this->getOrderItem($id), $token, $PayerID);

            $data = [
                'product_id' => $id,
                'quantity'   => 1
            ];

            if (Order::create($data)) {
                //Update stocks
                $ingredients = Ingredient::where('product_id', $id)->get();

                foreach ($ingredients as $ingredient) {
                    $material = RawMaterial::find($ingredient->raw_materials_id);
                    $currentStock = $material->quantity;
                    $material->quantity = $currentStock - $ingredient->quantity;

                    $material->save();
                }
            }

            return redirect('/menu')->with('success', 'Thank you for the payment. Your order was placed successfully');
        }

        return redirect('/menu')->with('error', 'Error processing PayPal payment');
    }
}
