<?php

namespace App\Http\Controllers;

use App\ContactMessage;
use Illuminate\Http\Request;

class ContactMessagesController extends Controller
{
    public function index()
    {
        $messages = ContactMessage::paginate(10);

        return view('admin.contact-messages')->with(['messages' => $messages]);
    }
}
