<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $users = User::where('role', '!=', 'admin')->paginate(10);

        $data = [
            'users' => $users,
        ];

        return view('admin.user.index')->with($data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $data = [
            'user' => [],
            'id'   => 0
        ];

        return view('admin.user.create')->with($data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request, $id = 0)
    {
        $passwordRequred = ($id > 0) ? 'nullable' : 'required';

        $validatedData = $request->validate([
            'name'     => 'required|string|max:255',
            'email'    => 'required|string|email|max:255|unique:users,email,' . $id,
            'password' => $passwordRequred . '|string|confirmed',
        ]);

        $data = $request->only(['name', 'email', 'password']);
        $data['role'] = 'staff';

        if (isset($data['password']) && $data['password'])
            $data['password'] = bcrypt($data['password']);
        else
            unset($data['password']);


        if ($id > 0) {
            User::find($id)->update($data);
        } else {
            User::create($data);
        }

        return back()->with('success', 'User has been saved');
    }


    /**
     * Show the form for editing the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data = [
            'user' => User::find($id),
            'id'   => $id
        ];

        return view('admin.user.create')->with($data);
    }


    /**
     * Remove the specified resource from storage.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        if ($id > 0) {
            User::destroy([$id]);
            return back()->with('success', 'Item has been deleted successfully');
        } else {
            return back()->with('error', 'Item Not Found');
        }
    }
}
