<?php

namespace App\Http\Controllers;

use App\Ingredient;
use App\Product;
use App\RawMaterial;
use Illuminate\Http\Request;

class IngredientsController extends Controller
{
    public function add($menuId = 0)
    {
        $menu = Product::find($menuId);
        $ingredients = Ingredient::where('product_id', $menuId)->get();
        $materials = RawMaterial::all();

        $data = [
            'menu_id'     => $menuId,
            'materials'   => $materials,
            'ingredients' => $ingredients,
            'menu'        => $menu,
        ];

        return view('admin.ingredient.add')->with($data);
    }

    public function store(Request $request, $menuId = 0)
    {
        $ingredients = $request->quantity;
        foreach ($ingredients as $key => $value) {
            if ($value > 0) {
                $data = [
                    'raw_materials_id' => $key,
                    'product_id'       => $menuId,
                    'quantity'         => $value,
                ];

                Ingredient::create($data);
            }
        }

        return back()->with('success', 'Ingredients saved');
    }

    public function delete($id = 0)
    {
        if ($id > 0) {
            Ingredient::destroy([$id]);
            return back()->with('success', 'Ingredients deleted successfully');
        } else {
            return back()->with('error', 'Ingredients Not Found');
        }

    }

}
