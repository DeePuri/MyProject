<?php

namespace App\Http\Controllers;

use App\Ingredient;
use App\Order;
use App\RawMaterial;
use Illuminate\Http\Request;

class OrdersController extends Controller
{
    //Public View
    public function placeOrder($id)
    {
        if ($id < 1) {
            return back()->with('error', 'Item not found');
        }

        $data = [
            'product_id' => $id,
            'quantity'   => 1
        ];

        if (Order::create($data)) {
            //Update stocks
            $ingredients = Ingredient::where('product_id', $id)->get();

            foreach ($ingredients as $ingredient) {
                $material = RawMaterial::find($ingredient->raw_materials_id);
                $currentStock = $material->quantity;
                $material->quantity = $currentStock - $ingredient->quantity;

                $material->save();
            }
        }

        return back()->with('success', 'Ordered placed successfully');
    }


    public function index() {
        $orders = Order::paginate(10);
        $data = [
            'orders' => $orders,
        ];

        return view('admin.orders.index')->with($data);
    }
}
