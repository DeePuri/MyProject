<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SalesReportController extends Controller
{
    public function report()
    {
        return view('admin.sales.sales-report');
    }
}
