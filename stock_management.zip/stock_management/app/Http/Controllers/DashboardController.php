<?php

namespace App\Http\Controllers;

use App\Order;
use App\Product;
use App\RawMaterial;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function index()
    {
        $orders = Order::selectRaw("COUNT(*) count, DATE(created_at) date")
            ->groupBy('date')
            ->get();

        $orderData = [];

        foreach ($orders as $order) {
            $orderData[$order->date] = $order->count;
        }

        $data = [
            'orders'     => Order::count(),
            'today'      => Order::whereDate('created_at', Carbon::today())->count(),
            'menus'      => Product::count(),
            'materials'  => RawMaterial::count(),
            'stocks'     => RawMaterial::orderBy('quantity', 'ASC')->paginate(5),
            'chartData'  => json_encode(array_values($orderData)),
            'chartLabel' => json_encode(array_keys($orderData)),
        ];


        return view('admin.dashboard')->with($data);
    }
}
