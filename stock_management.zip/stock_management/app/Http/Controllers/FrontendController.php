<?php

namespace App\Http\Controllers;

use App\ContactMessage;
use App\Menu;
use App\Product;
use App\Team;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class FrontendController extends Controller
{

    public function index()
    {
        return view('frontend.home');
    }

    public function team()
    {
        return view('frontend.team')->with(['teamMembers' => Team::$teamMembers]);
    }

    public function menu()
    {
        $data = [
            'menus' => Product::all()
        ];
        return view('frontend.menu')->with($data);
    }

    public function dish($slug = '')
    {
        if (!$slug || $slug == '')
            return redirect('/menu');

        $dish = Product::where('slug', $slug)->first();

        $price = number_format($dish->price, 2);
        $totalTip = $price * 0.10;

        $data = [
            'dish' => $dish,
            'tip' => $totalTip
        ];

        return view('frontend.dish')->with($data);
    }

    public function contact($submit = '')
    {
        return view('frontend.contact')->with(['submitted' => $submit]);
    }

    public function contactUs(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name'    => 'required',
            'email'   => 'required|email',
            'message' => 'required',
        ]);

        if ($validator->fails()) {
            return redirect('/contact')
                ->withErrors($validator)
                ->withInput();
        }

        $name = $request->name;
        $email = $request->email;
        $msg = $request->message;


        // Add the recipient email to a variable
        $to = "alok@resume722.ml";

        // Create a subject
        $subject = "$name sent a message via your contact form";

        // Construct the message
        $message = "Name: $name\r\n";
        $message .= "Email: $email\r\n\r\n";
        $message .= "Message:\r\n$msg";

        // If the subscribe checkbox was checked
        if (isset($_POST['subscribe']) && $_POST['subscribe'] == 'Subscribe') {

            // Add a new line to the $message
            $message .= "\r\n\r\nPlease add $email to the mailing list.\r\n";

        }
        $message = wordwrap($message, 72); // Keep the message neat n' tidy

        // Set the mail headers into a variable
        $headers = "MIME-Version: 1.0\r\n";
        $headers .= "Content-type: text/plain; charset=iso-8859-1\r\n";
        $headers .= "From: " . $name . " <" . $email . ">\r\n";
        $headers .= "X-Priority: 1\r\n";
        $headers .= "X-MSMail-Priority: High\r\n\r\n";

        // Send the email!
        mail($to, $subject, $message, $headers);

        $data = $request->only(['name', 'email', 'message']);
        (new ContactMessage())->saveMessage($data);

        return redirect('/contact/submitted');
    }

    public function reservation()
    {
        return view('frontend.reservation');
    }

}
