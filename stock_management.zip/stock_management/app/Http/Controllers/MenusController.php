<?php

namespace App\Http\Controllers;

use App\Product;
use Illuminate\Http\Request;

class MenusController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $menus = Product::paginate(10);
        $data = [
            'menus' => $menus,
        ];

        return view('admin.menu.index')->with($data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $data = [
            'menu' => [],
            'id'   => 0
        ];

        return view('admin.menu.create')->with($data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request, $id = 0)
    {
        $validatedData = $request->validate([
            'product_name' => 'required',
            'price'        => 'required|numeric',
        ]);

        $data = $request->only(['product_name', 'price']);
        $data['slug'] = str_slug($request->product_name);

        if ($id > 0) {
            Product::find($id)->update($data);
        } else {
            Product::create($data);
        }

        return back()->with('success', 'Menu has been saved');
    }


    /**
     * Show the form for editing the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data = [
            'menu' => Product::find($id),
            'id'   => $id
        ];

        return view('admin.menu.create')->with($data);
    }


    /**
     * Remove the specified resource from storage.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        if ($id > 0) {
            Product::destroy([$id]);
            return back()->with('success', 'Item has been deleted successfully');
        } else {
            return back()->with('error', 'Item Not Found');
        }
    }
}
