<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Team extends Model
{
    public static $teamMembers = [
        [
            "name"     => "Dee",
            "position" => "Owner",
            "bio"      => "Dee is the great-grandson of the original Franklin. He is the owner of Urban Zest Cafe. He cooks a mean fritatta!",
            "img"      => "frankie"
        ],

        [
            "name"     => "Bikash",
            "position" => "General Manager",
            "bio"      => "Bikash knows his stuff. He runs the show. Don't miss his Margherita Mondays!",
            "img"      => "carlos"
        ],

        [
            "name"     => "Dev",
            "position" => "Head Chef",
            "bio"      => "Dev is the epitome of the phrase &ldquo;Don't judge a book by it's cover&rdquo; &mdash; You simply cannot find a better chef.",
            "img"      => "carlos"

        ],
        [
            "name"     => "Kamrani",
            "position" => "Head Chef",
            "bio"      => "Kamrani is the table manager. If you want to reserve a table, you should ask her. ",
            "img"      => "francis"

        ],

    ];
}
