<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Menu extends Model
{



    public static $menus = [
        "club-soda" => [

            "title" => "Coffee",
            "price" => 5,
            "blurb" => "",
            "drink" => "Club Soda"
        ],

        "dill-salmon" => [

            "title" => "Toasts with crispy bacon and Salad",
            "price" => 15,
            "blurb" => "Pork belly tempor ground round qui exercitation, jowl leberkas sed voluptate excepteur jerky. Reprehenderit veniam cow, quis in ribeye andouille eu pastrami eiusmod exercitation dolor.",
            "drink" => "Fancy Wine"

        ],

        "super-salad" => [

            "title" => "Fruit Bowls",
            "price" => 18,
            "blurb" => "Gumbo beet greens corn soko endive gumbo gourd. Parsley shallot courgette tatsoi pea sprouts fava bean collard greens dandelion okra wakame tomato. Dandelion cucumber earthnut pea peanut soko zucchini.",
            "drink" => "Jug o' Water"

        ],

        "mexican-barbacoa" => [

            "title" => "Heavy Delight",
            "price" => 20,
            "blurb" => "I love fruitcake danish caramels. Tart danish pastry liquorice chocolate cake fruitcake. Bear claw gingerbread muffin I love apple pie apple pie tiramisu brownie chocolate. Sweet roll cotton candy cupcake gingerbread gummies jelly-o. Muffin I love croissant I love jelly-o brownie jelly beans. Toffee I love pastry.",
            "drink" => "Beer with a lime"

        ],
    ];
}
