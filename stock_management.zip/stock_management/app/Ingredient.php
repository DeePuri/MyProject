<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Ingredient extends Model
{
    protected $fillable = [
        'raw_materials_id', 'product_id', 'quantity'
    ];

    public function raw_material()
    {
        return $this->belongsTo(RawMaterial::class, 'raw_materials_id', 'id');
    }
}
